<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="you can book your ambulance || you go to your hospital as soon as possible"/>
        <meta name="keywords" content="SEO, Hacker, Google, Search, etc"/>
        <title>Get your Ambulance</title>
        <script src="JS/javascript"></script>
        <link rel="stylesheet" href="getAmbulance.css">
        <link rel="stylesheet" href="all.css">
        <link rel="stylesheet" href="pro-fonts.css">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </head>
    <body>
        <header>
            <div class="header">
<body ng-app="rxApp">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Booambu</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="getAmbulance.html">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="/sendMedicalReport.php">Send Medical Report</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Send Medical Report</a></li>
                <li class="divider"></li>
                <li class="dropdown-header">Nav header</li>
                <li><a href="#">Separated link</a></li>
                <li><a href="#">One more separated link</a></li>
              </ul>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../navbar/">Default</a></li>
            <li><a href="../navbar-static-top/">Static top</a></li>
            <li class="active"><a href="./">Fixed top <span class="sr-only">(current)</span></a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


 		
<div class="table-responsive nearbyAmbulances line"><p>________________________________________________________________________________________________________________________________________________________________________</p></div>

  <label><b>Patient Name:-</b></label> 
  <input  type="text" name="Patient Name" placeholder="Patient Name"><br><br>

  <label><b>Patient Aadhar Number :-</b></label> 
  <input  type="text" name="Patient Aadhar Number " placeholder="Patient Aadhar Number "><br><br>

  <label><b>From :-</b></label> 
  <input  type="text" name="From " placeholder="From "><br><br>

  <h2>Conditions:-</h2>

  <input type="checkbox" name="Condition" >Blood Pressure<br>
 
<input type="checkbox" name="Condition" > Migrane<br>
 <input type="checkbox" name="Condition" > Arthiris<br>
 <input type="checkbox" name="Condition" > Chronic lower back pain<br>
 <input type="checkbox" name="Condition" > Allegries/Sinus<br>
 <input type="checkbox" name="Condition" > Asthma<br>
 <input type="checkbox" name="Condition" > Acid Reflux<br>
 <input type="checkbox" name="Condition" > Skin Condition<br>
 <input type="checkbox" name="Condition" > Influenze<br>
 <input type="checkbox" name="Condition" > Depression/Anxiety<br>
 <input type="checkbox" name="Condition" > Due to Accident<br>
 
<input type="submit" name="SendReport" value="Send Report" style="color:lightgreen;background-color: brown ">
    </div></div>



        </header>
    </body>
</html>