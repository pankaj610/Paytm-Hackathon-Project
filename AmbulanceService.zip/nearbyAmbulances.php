<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="you can book your ambulance || you go to your hospital as soon as possible"/>
        <meta name="keywords" content="SEO, Hacker, Google, Search, etc"/>
        <title>Get your Ambulance</title>
        <script src="JS/javascript"></script>
        <link rel="stylesheet" href="getAmbulance.css">
        <link rel="stylesheet" href="all.css">
        <link rel="stylesheet" href="pro-fonts.css">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </head>
    <body>
        <header>
            <div class="header">
<body ng-app="rxApp">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Booambu</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="sendMedicalReport.php">Send Medical Report</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Send Medical Report</a></li>
                <li class="divider"></li>
                <li class="dropdown-header">Nav header</li>
                <li><a href="#">Separated link</a></li>
                <li><a href="#">One more separated link</a></li>
              </ul>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../navbar/">Default</a></li>
            <li><a href="../navbar-static-top/">Static top</a></li>
            <li class="active"><a href="./">Fixed top <span class="sr-only">(current)</span></a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    		<h2>Your's Location </h2>
    		<CENTER><h2>Nearby Available Ambulance </h2></CENTER>
    		<div class="table-responsive">
            <center><table class="nearbyAmbulances table table-hover" style="color:black;">
              <th>
                <td>Hospital Associated</td>
                <td>Location</td>
                <td>Distance(Km)</td>
                <td>Time Taken(Min)</td>
                <td>Fair</td>
                <td>Choose Option</td>
              </th>
              <tr>
              	<td></td>
                <td>Richa Hospital</td>
                <td>Block E, Katwaria Sarai, New Delhi, Delhi 110016</td>
                <td>1.1Km</td>
                <td>11Min</td>
                <td>250 sRs</td>
                <td><a href="https://www.google.co.in/maps/dir/Richa+Hospital,+Block+E,+Katwaria+Sarai,+New+Delhi,+Delhi/Central+Workshop,+IIT+Delhi,+IIT+Campus,+Jia+Sarai,+Hauz+Khas,+New+Delhi,+Delhi+110016/@28.5439864,77.187334,17z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x390d1df102c2019f:0x49b88ecff9fa6593!2m2!1d77.1865296!2d28.543103!1m5!1m1!1s0x390d1df6546dc2bd:0x133b2199b8dbfcae!2m2!1d77.1921216!2d28.5438617">Click Here</td>
              </tr>
              <tr>
              	<td></td>
                <td>Neptune Hospital</td>
                <td>1, Nav Jeevan Vihar, Shivalik, Geetanjali Marg, Shivalik Enclave, Navjeevan Vihar, Adchini, New Delhi, Delhi 110017</td>
                <td>5.1Km</td>
                <td>12Min</td>
                <td>350 sRs</td>
                <td><a href="https://www.google.co.in/maps/dir/Neptune+Hospital,+1,+Nav+Jeevan+Vihar,+Shivalik,+Geetanjali+Marg,+Adchini,+New+Delhi,+Delhi+110017/Central+Library,+IIT+Campus,+Hauz+Khas,+New+Delhi,+Delhi+110016/@28.5375779,77.1896262,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x390ce202501bee5f:0xf4b06759a3911884!2m2!1d77.202654!2d28.5324525!1m5!1m1!1s0x390d1df6f4136245:0x77ecaff1b3699806!2m2!1d77.1914529!2d28.544661">Click Here</td>
              </tr>
              <tr>
              	<td></td>
                <td>Shivam Hospital & Heart Centre</td>
                <td>Block E, Katwaria Sarai, New Delhi, Delhi 110016</td>
                <td>2.1Km</td>
                <td>17Min</td>
                <td>250 sRs</td>
                <td><a href="https://www.google.co.in/maps/dir/Richa+Hospital,+Block+E,+Katwaria+Sarai,+New+Delhi,+Delhi/Central+Workshop,+IIT+Delhi,+IIT+Campus,+Jia+Sarai,+Hauz+Khas,+New+Delhi,+Delhi+110016/@28.5439864,77.187334,17z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x390d1df102c2019f:0x49b88ecff9fa6593!2m2!1d77.1865296!2d28.543103!1m5!1m1!1s0x390d1df6546dc2bd:0x133b2199b8dbfcae!2m2!1d77.1921216!2d28.5438617">Click Here</td>
              </tr>
              <tr>
              	<td></td>
                <td>IITD Hospital Substation</td>
                <td>IIT Campus, Indian Institute of Technology Delhi, Hauz Khas, New Delhi, Delhi 110016</td>
                <td>450m</td>
                <td>5Min</td>
                <td>20 sRs</td>
                <td><a href="https://www.google.co.in/maps/dir/Richa+Hospital,+Block+E,+Katwaria+Sarai,+New+Delhi,+Delhi/Central+Workshop,+IIT+Delhi,+IIT+Campus,+Jia+Sarai,+Hauz+Khas,+New+Delhi,+Delhi+110016/@28.5439864,77.187334,17z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x390d1df102c2019f:0x49b88ecff9fa6593!2m2!1d77.1865296!2d28.543103!1m5!1m1!1s0x390d1df6546dc2bd:0x133b2199b8dbfcae!2m2!1d77.1921216!2d28.5438617">Click Here</td>
              </tr>

            </table></center></div>
        </header>
    </body>
</html>